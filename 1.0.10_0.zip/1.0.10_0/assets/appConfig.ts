const AppConfig = {
  cxone_agent_app_url: 'https://cxagent.nicecxone.com/',
};

export default AppConfig;
